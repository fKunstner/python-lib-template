"""
Hello World
==============================
"""

import mylib

# %%
# Notebook type comments

mylib.hello_world()
